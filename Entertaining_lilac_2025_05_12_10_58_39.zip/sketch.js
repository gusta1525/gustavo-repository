let jardineiro, plantas = [], temperatura = 10, totalArvores = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = { x: width / 2, y: height - 50, vel: 5 };
}

function draw() {
  let cor = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(cor);
  fill(0); textSize(16);
  text("🌡️ " + temperatura.toFixed(1) + "°C", 10, 20);
  text("🌳 " + totalArvores, 10, 40);
  text("🅿️ 'P' planta árvore", 10, 60);
  temperatura += 0.02;
  if (keyIsDown(LEFT_ARROW)) jardineiro.x -= jardineiro.vel;
  if (keyIsDown(RIGHT_ARROW)) jardineiro.x += jardineiro.vel;
  if (keyIsDown(UP_ARROW)) jardineiro.y -= jardineiro.vel;
  if (keyIsDown(DOWN_ARROW)) jardineiro.y += jardineiro.vel;
  jardineiro.x = constrain(jardineiro.x, 0, width - 30);
  jardineiro.y = constrain(jardineiro.y, 0, height - 30);
  fill(100, 150, 255); rect(jardineiro.x, jardineiro.y, 30, 30);
  plantas.forEach(p => {
    fill(34, 139, 34); ellipse(p.x + 15, p.y, 30, 30);
    fill(139, 69, 19); rect(p.x + 10, p.y, 10, 20);
  });
  if (temperatura >= 40) {
    noLoop(); fill(255, 0, 0); textSize(22);
    text("🔥 Planeta aqueceu!", 180, height / 2);
  } else if (totalArvores >= 100) {
    noLoop(); fill(0, 200, 0); textSize(22);
    text("🎉 Você salvou o planeta!", 120, height / 2);
  }
}

function keyPressed() {
  if (key === 'P' || key === 'p') {
    plantas.push({ x: jardineiro.x, y: jardineiro.y });
    totalArvores++; temperatura = max(0, temperatura - 0.5);
  }
}